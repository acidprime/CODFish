#!/bin/bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin export PATH
declare -x awk="/usr/bin/awk"
declare -x dscl="/usr/bin/dscl"
declare -x GROUP_NAME="$1"

# Edit the following settings to match your environment
mbr_enum=/Users/its_admin/Desktop/create_augments/mbr_enum
dry_run=no # set to "no" when you're ready to do this for real
DIRECTORY_SERVICE="/LDAPv3/127.0.0.1"
HOME_URL="afp://xvh-m-cmm-fil-1.slu.loc/Users"
HOME_PATH="/Network/Servers/xvh-m-cmm-fil-1.slu.loc/Volumes/DATA1/Users"
PGID=20



if [ $dry_run == "no" ]; then
	mkfifo /tmp/f
	$dscl "$DIRECTORY_SERVICE" < /tmp/f &
else
	rm /tmp/f
fi
updateAugments(){
declare GROUP_NAME="$1"
OLD_IFS="$IFS"
IFS=$'\n'
for LINE in `$mbr_enum "$GROUP_NAME"` ; do

declare -x SHORT_NAME="$(printf $LINE | awk -F'^' '{print $1;exit}')"
declare -x REAL_NAME="$(printf $LINE | awk -F'^' '{print $2;exit}')"
declare -xi UNIQUE_ID="$(printf $LINE | awk -F'^' '{print $3;exit}')"
declare -x UUID="$(dsmemberutil getuuid -u $UNIQUE_ID)"
echo "Processing $SHORT_NAME:$REAL_NAME:$UNIQUE_ID:$uuid"

declare -x CURRENT_NFSHOME_DIRECTORY="$($dscl /Search -read "/Users/$SHORT_NAME" NFSHomeDirectory | awk '{print $NF;exit}')"

if [ "$CURRENT_NFSHOME_DIRECTORY" = "$HOME_PATH/$SHORT_NAME" ] ; then
	echo "User: $SHORT_NAME is already configured"
	continue
fi

echo "" | $awk -v home_url="$HOME_URL" \
  -v home_path="$HOME_PATH" -v sn="$SHORT_NAME" -v ln="$REAL_NAME" -v uid="$UNIQUE_ID" -v group="$GROUP_NAME" -v uuid="$UUID" -v pgid="$PGID" '
BEGIN {
	print "auth diradmin c@rd1n@ls" >> "/tmp/f"
}
{
	printf("create /Augments/Users:%s RealName \"%s\"\n", sn, ln) >> "/tmp/f"
	printf("create /Augments/Users:%s GeneratedUID %s\n", sn, uuid) >> "/tmp/f"
	printf("create /Augments/Users:%s HomeDirectory <home_dir><url>%s</url><path>%s</path></home_dir>\n", sn, home_url, sn) >> "/tmp/f"
	printf("create /Augments/Users:%s NFSHomeDirectory %s/%s\n", sn, home_path, sn) >> "/tmp/f"
	printf("create /Augments/Users:%s UniqueID %s\n", sn, uid) >> "/tmp/f"
	printf("create /Augments/Users:%s PrimaryGroupID %s\n", sn, pgid) >> "/tmp/f"
	printf("create /Augments/Users:%s Keywords \"%s\"\n", sn, group) >> "/tmp/f"
}'
done
}

if [ ${#GROUP_NAME} -gt 0 ] ; then
	echo "Processing Single group $GROUP_NAME"
	updateAugments "$GROUP_NAME"
else
	echo "Processing all groups in $DIRECTORY_SERVICE"
	declare -ax OD_GROUPS=(`dscl "$DIRECTORY_SERVICE" -list /Groups`)
	for GROUP_NAME in ${OD_GROUPS[@]} ; do
		case "$GROUP_NAME" in
			staff )\
				continue ;;
			admin )\
				continue ;;
			com.apple.limited_admin )\
				 continue ;;
		esac
		updateAugments $GROUP_NAME
	done
fi
if [ $dry_run == "no" ]; then
	rm /tmp/f
else
	open -e /tmp/f
fi
